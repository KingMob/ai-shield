<?php
    
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
    

/**
 * Provide a public-facing view for the plugin. Currently unused, but left in for the future
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @since      1.0.0
 *
 * @package    Ai_Shield
 * @subpackage Ai_Shield/public/partials
 */
?>
